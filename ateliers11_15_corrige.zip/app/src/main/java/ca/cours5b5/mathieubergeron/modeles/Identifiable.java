package ca.cours5b5.mathieubergeron.modeles;



public interface Identifiable {

    String getId();

}

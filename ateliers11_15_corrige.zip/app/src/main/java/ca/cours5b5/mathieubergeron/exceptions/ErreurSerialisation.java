package ca.cours5b5.mathieubergeron.exceptions;


public class ErreurSerialisation extends RuntimeException {

    public ErreurSerialisation(String message){
        super(message);
    }

}

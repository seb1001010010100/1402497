package ca.cours5b5.mathieubergeron.controleurs.interfaces;


import ca.cours5b5.mathieubergeron.modeles.Modele;

public interface ListenerGetModele {

    void reagirAuModele(Modele modele);

}

package ca.cours5b5.mathieubergeron.vues;

import android.content.Context;
import android.util.AttributeSet;

import ca.cours5b5.mathieubergeron.R;
import ca.cours5b5.mathieubergeron.controleurs.ControleurObservation;
import ca.cours5b5.mathieubergeron.controleurs.interfaces.ListenerObservateur;
import ca.cours5b5.mathieubergeron.exceptions.ErreurObservation;
import ca.cours5b5.mathieubergeron.modeles.MParametresPartie;
import ca.cours5b5.mathieubergeron.modeles.MPartie;
import ca.cours5b5.mathieubergeron.modeles.MPartieReseau;
import ca.cours5b5.mathieubergeron.modeles.Modele;


public class VPartieReseau extends VPartie {


    private VGrille grille;


    public VPartieReseau(Context context) {
        super(context);
    }

    public VPartieReseau(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public VPartieReseau(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected String getNomModele(){
        return MPartieReseau.class.getSimpleName();
    }

}

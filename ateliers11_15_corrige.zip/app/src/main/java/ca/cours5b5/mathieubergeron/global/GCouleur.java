package ca.cours5b5.mathieubergeron.global;

public enum GCouleur {

    ROUGE, JAUNE;

}
